# Tradition Agro — Prototipo (GitHub Pages)

Este repositorio contiene un prototipo estático para publicar en **GitHub Pages**.

## Instrucciones de despliegue
1. Sube **index.html**, la carpeta **assets/** y el archivo **.nojekyll** a tu repositorio.
2. Ve a **Settings → Pages**.
3. En **Source**, selecciona `Deploy from a branch`.
4. Selecciona la rama `main` y la carpeta `/ (root)`.
5. Guarda y espera a que GitHub Pages genere el enlace.

El archivo `.nojekyll` es obligatorio para evitar conflictos con la carpeta **assets/**.
